package com.portfolio.lagb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagbApplicationTests {

	@Test
	void contextLoads() {
	}

}
