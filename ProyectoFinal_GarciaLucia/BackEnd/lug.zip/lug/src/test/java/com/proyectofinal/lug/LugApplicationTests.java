package com.proyectofinal.lug;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LugApplicationTests {

	@Test
	void contextLoads() {
	}

}
