package com.proyectofinal.lug;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LugApplication {

	public static void main(String[] args) {
		SpringApplication.run(LugApplication.class, args);
	}

}
